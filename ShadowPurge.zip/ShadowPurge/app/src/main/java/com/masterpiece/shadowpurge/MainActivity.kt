package com.masterpiece.shadowpurge

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Crimson = Color(0xFFDC143C)
private val Ice = Color(0xFF7FDBFF)
private val Bg = Color(0xFF0A0A0F)
private val Panel = Color(0xFF16161F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this); Game.load(); Messages.load(this)
        Notifier.channel(this); Scheduler.scheduleAll(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Crimson, secondary = Ice, background = Bg, surface = Panel)) {
                App()
            }
        }
    }
}

@Composable
fun App() {
    val tabs = listOf("Hunter", "Missions", "World", "Alerts", "Lab")
    var tab by remember { mutableStateOf(0) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS) }
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Panel) {
            tabs.forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(t.take(1)) }, label = { Text(t, fontSize = 11.sp) })
            }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(16.dp)) {
            Text("SHADOW PURGE", color = Crimson, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("MONSTER HUNTER SYSTEM  •  BY MASTERPIECE", color = Ice, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            when (tab) {
                0 -> Hunter(); 1 -> Missions(); 2 -> World(); 3 -> Alerts(); else -> Lab()
            }
        }
    }
}

@Composable fun Card2(content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).background(Panel, RoundedCornerShape(12.dp)).padding(14.dp), content = content)

@Composable
fun Hunter() = LazyColumn {
    item {
        Card2 {
            Text("RANK ${Game.rank}  •  LEVEL ${Game.level}", color = Ice, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("XP ${Game.xp}  •  Streak ${Game.streak} days  •  Bosses defeated ${Game.defeated}", color = Color.LightGray, fontSize = 13.sp)
        }
        Card2 {
            Text(Game.boss.name, color = Crimson, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("${Game.boss.country}  •  Stage: ${Game.stages[Game.stage]}", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = { Game.power / 100f }, color = Crimson, modifier = Modifier.fillMaxWidth())
            Text("Power ${Game.power}/100", color = Color.Gray, fontSize = 12.sp)
            Text("\"${Game.boss.line}\"", color = Color.White, fontSize = 13.sp)
        }
        Card2 {
            Text("HUNTER STATS", color = Ice, fontWeight = FontWeight.Bold)
            Game.attrs.forEach { a ->
                val v = Game.stats[a] ?: 0
                Text("$a: $v", color = Color.White, fontSize = 14.sp)
                LinearProgressIndicator(progress = { (v % 20) / 20f }, color = Ice, modifier = Modifier.fillMaxWidth())
            }
        }
        Card2 {
            Text("WEEKLY MISSIONS DONE (oldest to today)", color = Ice, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth().height(80.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceEvenly) {
                Game.week.forEach { n ->
                    Box(Modifier.width(24.dp).height((8 + n * 10).dp).background(Crimson, RoundedCornerShape(4.dp)))
                }
            }
        }
    }
}

@Composable
fun Missions() {
    var confirm by remember { mutableStateOf(false) }
    LazyColumn {
        items(Game.missions) { m ->
            Card2 {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.title, color = Color.White)
                        Text("+${m.xp} XP  •  ${m.attr}", color = Ice, fontSize = 12.sp)
                    }
                    Button(onClick = { Game.complete(m) }, enabled = m.id !in Game.done) { Text(if (m.id in Game.done) "Done" else "Complete") }
                }
            }
        }
        item {
            Spacer(Modifier.height(12.dp))
            Text("Safety: warm up first and stop if you feel pain or dizziness.", color = Color.Gray, fontSize = 12.sp)
            OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("I had a setback (private, no XP lost)") }
        }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        title = { Text("Record a setback?") },
        text = { Text("This only resets your streak and gives the boss a little power back. Your XP and stats stay. One day does not define you.") },
        confirmButton = { TextButton(onClick = { Game.setback(); confirm = false }) { Text("Record") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } })
}

@Composable
fun World() = LazyColumn {
    items(Game.bosses.indices.toList()) { i ->
        val b = Game.bosses[i]
        val status = when { i < Game.bossIdx -> "DEFEATED"; i == Game.bossIdx -> "CURRENT"; else -> "LOCKED" }
        Card2 {
            Text(b.name, color = if (i <= Game.bossIdx) Crimson else Color.Gray, fontWeight = FontWeight.Bold)
            Text("${b.country}  •  $status", color = Ice, fontSize = 12.sp)
            if (i <= Game.bossIdx) Text("\"${b.line}\"", color = Color.White, fontSize = 13.sp)
            Text("Fictional monster. No country or people are evil.", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun Alerts() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var en by remember { mutableStateOf(Store.enabled) }
    var times by remember { mutableStateOf(Store.times) }
    var qs by remember { mutableStateOf(Store.quietStart) }
    var qe by remember { mutableStateOf(Store.quietEnd) }
    var lim by remember { mutableStateOf(Store.dailyLimit) }
    var preview by remember { mutableStateOf("") }
    var hist by remember { mutableStateOf(Store.history) }
    fun apply() { Store.enabled = en; Store.times = times; Store.quietStart = qs; Store.quietEnd = qe; Store.dailyLimit = lim; Scheduler.scheduleAll(ctx) }
    LazyColumn {
        item {
            Card2 {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Notifications", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(checked = en, onCheckedChange = { en = it; apply() })
                }
                Text("Android may delay alerts on some phones due to battery saving. Exact alarms improve punctuality but are not guaranteed.", color = Color.Gray, fontSize = 11.sp)
                if (!Scheduler.canExact(ctx)) OutlinedButton(onClick = {
                    if (Build.VERSION.SDK_INT >= 31) ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
                }) { Text("Allow exact alarms") }
            }
            Card2 {
                Text("Times (max ${Scheduler.SLOTS})", color = Ice, fontWeight = FontWeight.Bold)
                times.forEach { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("%02d:%02d".format(t / 60, t % 60), color = Color.White, modifier = Modifier.weight(1f))
                        TextButton(onClick = { times = times - t; apply() }) { Text("Remove") }
                    }
                }
                Button(onClick = {
                    TimePickerDialog(ctx, { _, h, m -> if (times.size < Scheduler.SLOTS) { times = (times + (h * 60 + m)).distinct().sorted(); apply() } }, 9, 0, true).show()
                }) { Text("Add time") }
            }
            Card2 {
                Text("Quiet hours: %02d:00 to %02d:00".format(qs, qe), color = Color.White)
                Row { 
                    TextButton(onClick = { qs = (qs + 1) % 24; apply() }) { Text("Start +1h") }
                    TextButton(onClick = { qe = (qe + 1) % 24; apply() }) { Text("End +1h") }
                }
                Text("Daily limit: $lim", color = Color.White)
                Row {
                    TextButton(onClick = { lim = (lim - 1).coerceAtLeast(1); apply() }) { Text("-") }
                    TextButton(onClick = { lim = (lim + 1).coerceAtMost(12); apply() }) { Text("+") }
                }
            }
            Card2 {
                Button(onClick = { val m = Messages.next(ctx); preview = m.title + ": " + m.body; Notifier.show(ctx, m); hist = Store.history }) { Text("Send test notification") }
                if (preview.isNotEmpty()) Text(preview, color = Color.White, fontSize = 13.sp)
                Text("${Messages.count()} messages in library", color = Color.Gray, fontSize = 11.sp)
            }
            Text("HISTORY", color = Ice, fontWeight = FontWeight.Bold)
        }
        items(hist.reversed()) { Text(it, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp)) }
    }
}

@Composable
fun Lab() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var a by remember { mutableStateOf((2..12).random()) }
    var b by remember { mutableStateOf((2..12).random()) }
    var ans by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var reset by remember { mutableStateOf(false) }
    LazyColumn {
        item {
            Card2 {
                Text("INTELLIGENCE LAB: Mental Math", color = Ice, fontWeight = FontWeight.Bold)
                Text("$a x $b = ?", color = Color.White, fontSize = 22.sp)
                OutlinedTextField(value = ans, onValueChange = { ans = it }, singleLine = true)
                Button(onClick = {
                    if (ans.trim().toIntOrNull() == a * b) { msg = "Correct!"; a = (2..12).random(); b = (2..12).random(); ans = "" } else msg = "Try again."
                }) { Text("Check") }
                Text(msg, color = Ice)
            }
            Card2 {
                Text("FITNESS LAB: Beginner routine", color = Ice, fontWeight = FontWeight.Bold)
                Text("Warm-up 5 min, Knee/regular push-ups 3x8, Squats 3x12, Plank 3x20s, Mobility 5 min, then walk. Rest 60s between sets. Rest day every 2nd-3rd day. Stop if pain or dizziness.", color = Color.White, fontSize = 13.sp)
            }
            Card2 {
                Text("STRATEGY / SOCIAL", color = Ice, fontWeight = FontWeight.Bold)
                Text("Write one fact and one assumption about a situation today. In a conversation, repeat back what you heard before replying.", color = Color.White, fontSize = 13.sp)
            }
            Card2 {
                OutlinedButton(onClick = { reset = true }) { Text("Reset all data") }
            }
        }
    }
    if (reset) AlertDialog(onDismissRequest = { reset = false },
        title = { Text("Reset everything?") }, text = { Text("This permanently deletes progress and settings on this device.") },
        confirmButton = { TextButton(onClick = { Game.reset(); Scheduler.scheduleAll(ctx); reset = false }) { Text("Reset") } },
        dismissButton = { TextButton(onClick = { reset = false }) { Text("Cancel") } })
}
