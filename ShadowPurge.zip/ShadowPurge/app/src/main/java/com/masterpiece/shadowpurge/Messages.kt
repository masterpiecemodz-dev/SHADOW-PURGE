package com.masterpiece.shadowpurge

import android.content.Context

data class Msg(val id: Int, val category: String, val title: String, val body: String)

object Messages {
    private var all: List<Msg> = emptyList()
    fun load(c: Context) {
        if (all.isNotEmpty()) return
        val text = c.resources.openRawResource(R.raw.messages).bufferedReader().readText()
        all = text.lines().filter { it.isNotBlank() }.mapIndexed { i, l ->
            val parts = l.split("|")
            Msg(i, parts[0], parts[1], parts[2])
        }
    }
    fun count() = all.size
    fun next(c: Context): Msg {
        load(c)
        var seen = Store.recent
        var pool = all.filter { it.id !in seen }
        if (pool.isEmpty()) { seen = seen.takeLast(1); pool = all.filter { it.id !in seen } }
        val m = pool.random()
        Store.recent = seen + m.id
        return m
    }
}
