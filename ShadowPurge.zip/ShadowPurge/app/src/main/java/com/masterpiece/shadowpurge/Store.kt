package com.masterpiece.shadowpurge

import android.content.Context
import android.content.SharedPreferences
import java.time.LocalDate

object Store {
    lateinit var p: SharedPreferences
    fun init(c: Context) { if (!::p.isInitialized) p = c.applicationContext.getSharedPreferences("sp", Context.MODE_PRIVATE) }
    fun today(): String = LocalDate.now().toString()
    var enabled: Boolean get() = p.getBoolean("en", true); set(v) { p.edit().putBoolean("en", v).apply() }
    var times: List<Int>
        get() = p.getString("times", "540,900,1230")!!.split(",").mapNotNull { it.toIntOrNull() }
        set(v) { p.edit().putString("times", v.sorted().joinToString(",")).apply() }
    var quietStart: Int get() = p.getInt("qs", 23); set(v) { p.edit().putInt("qs", v).apply() }
    var quietEnd: Int get() = p.getInt("qe", 7); set(v) { p.edit().putInt("qe", v).apply() }
    var dailyLimit: Int get() = p.getInt("lim", 3); set(v) { p.edit().putInt("lim", v).apply() }
    fun sentToday(): Int = p.getInt("cnt_" + today(), 0)
    fun bumpSent() { p.edit().putInt("cnt_" + today(), sentToday() + 1).apply() }
    var recent: List<Int>
        get() = p.getString("recent", "")!!.split(",").mapNotNull { it.toIntOrNull() }
        set(v) { p.edit().putString("recent", v.takeLast(40).joinToString(",")).apply() }
    var history: List<String>
        get() = p.getString("hist", "")!!.split("\n").filter { it.isNotBlank() }
        set(v) { p.edit().putString("hist", v.takeLast(50).joinToString("\n")).apply() }
    fun isQuiet(hour: Int): Boolean {
        val s = quietStart; val e = quietEnd
        return if (s == e) false else if (s > e) hour >= s || hour < e else hour in s until e
    }
}
