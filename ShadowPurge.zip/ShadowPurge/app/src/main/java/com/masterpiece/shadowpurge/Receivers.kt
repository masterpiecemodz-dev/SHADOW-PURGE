package com.masterpiece.shadowpurge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.init(c)
        val slot = i.getIntExtra("slot", 0)
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (Store.enabled && !Store.isQuiet(hour) && Store.sentToday() < Store.dailyLimit) {
            Notifier.show(c, Messages.next(c))
            Store.bumpSent()
        }
        if (Store.enabled) Scheduler.scheduleSlot(c, slot)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.scheduleAll(c) }
}
