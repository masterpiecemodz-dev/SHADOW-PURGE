package com.masterpiece.shadowpurge

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar

object Notifier {
    private const val CH = "sp_monsters"
    fun channel(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Monster alerts", NotificationManager.IMPORTANCE_DEFAULT))
    }
    fun show(c: Context, m: Msg) {
        channel(c)
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(m.title).setContentText(m.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(m.body))
            .setContentIntent(pi).setAutoCancel(true).build()
        NotificationManagerCompat.from(c).notify((System.currentTimeMillis() % 100000).toInt(), n)
        val stamp = java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        Store.history = Store.history + (stamp + "  " + m.title + ": " + m.body)
    }
}

object Scheduler {
    const val SLOTS = 12
    private fun pi(c: Context, slot: Int) = PendingIntent.getBroadcast(c, 100 + slot,
        Intent(c, AlarmReceiver::class.java).putExtra("slot", slot),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    fun nextMillis(minuteOfDay: Int): Long {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, minuteOfDay / 60); set(Calendar.MINUTE, minuteOfDay % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 60_000) add(Calendar.DAY_OF_YEAR, 1)
        }
        return cal.timeInMillis
    }
    fun canExact(c: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
    fun scheduleSlot(c: Context, slot: Int) {
        val t = Store.times.getOrNull(slot) ?: return
        val am = c.getSystemService(AlarmManager::class.java)
        val at = nextMillis(t)
        if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, slot))
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, slot))
    }
    fun scheduleAll(c: Context) {
        Store.init(c)
        val am = c.getSystemService(AlarmManager::class.java)
        for (i in 0 until SLOTS) am.cancel(pi(c, i))
        if (!Store.enabled) return
        Store.times.take(SLOTS).indices.forEach { scheduleSlot(c, it) }
    }
}
