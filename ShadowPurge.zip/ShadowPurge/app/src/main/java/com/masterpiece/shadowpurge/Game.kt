package com.masterpiece.shadowpurge

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class Boss(val country: String, val name: String, val line: String)
data class Mission(val id: String, val title: String, val attr: String, val xp: Int)

object Game {
    val bosses = listOf(
        Boss("Pakistan", "THE CRIMSON DEVOURER", "Kya hua, Hunter? Aaj bhi mujhe defeat nahi karoge?"),
        Boss("Japan", "THE SILENT SHADOW", "Khamoshi mein bhi main dekh raha hoon."),
        Boss("Korea", "THE FROST TYRANT", "Meri barf tumhari discipline se pighlegi."),
        Boss("Egypt", "THE DESERT PHANTOM", "Registan lamba hai. Kya tum tayyar ho?"),
        Boss("China", "THE JADE NIGHTMARE", "Mere paas time hai. Tumhare paas plan hai?"),
        Boss("World", "THE ETERNAL SHADOW", "Antim yudh. Sab stats ready rakho."))
    val stages = listOf("Dormant", "Awakened", "Evolved", "Enraged", "Defeated")
    val missions = listOf(
        Mission("pf", "Porn-free day (self-reported)", "Discipline", 30),
        Mission("study", "Study / coding session (25 min)", "Intelligence", 20),
        Mission("fit", "Safe workout (with warm-up)", "Physical", 25),
        Mission("sleep", "Follow sleep routine", "Discipline", 15),
        Mission("logic", "Logic / observation exercise", "Observation", 15),
        Mission("plan", "Plan tomorrow (Strategy Room)", "Strategy", 15),
        Mission("soc", "Active listening / kind conversation", "Social", 15))
    val attrs = listOf("Intelligence", "Physical", "Strategy", "Observation", "Discipline", "Social")
    val ranks = listOf("E", "D", "C", "B", "A", "S", "SS", "SSS")
    private val thresholds = listOf(0, 100, 300, 600, 1000, 1600, 2500, 4000)

    var xp by mutableStateOf(0)
    var bossIdx by mutableStateOf(0)
    var power by mutableStateOf(100)
    var streak by mutableStateOf(0)
    var defeated by mutableStateOf(0)
    var done by mutableStateOf(setOf<String>())
    var stats by mutableStateOf(mapOf<String, Int>())
    var week by mutableStateOf(listOf<Int>())

    val rank get() = ranks[thresholds.indexOfLast { xp >= it }]
    val level get() = xp / 100 + 1
    val boss get() = bosses[bossIdx]
    val stage get() = when { power <= 0 -> 4; power > 75 -> 0; power > 50 -> 1; power > 25 -> 2; else -> 3 }

    fun load() {
        val p = Store.p
        xp = p.getInt("xp", 0); bossIdx = p.getInt("boss", 0); power = p.getInt("power", 100)
        streak = p.getInt("streak", 0); defeated = p.getInt("def", 0)
        done = p.getStringSet("done_" + Store.today(), emptySet())!!.toSet()
        stats = attrs.associateWith { p.getInt("stat_$it", 0) }
        week = (6 downTo 0).map { p.getInt("day_" + java.time.LocalDate.now().minusDays(it.toLong()), 0) }
    }
    private fun save() {
        val e = Store.p.edit()
        e.putInt("xp", xp).putInt("boss", bossIdx).putInt("power", power).putInt("streak", streak).putInt("def", defeated)
        e.putStringSet("done_" + Store.today(), done)
        stats.forEach { (k, v) -> e.putInt("stat_$k", v) }
        e.putInt("day_" + Store.today(), done.size)
        e.apply()
        week = (6 downTo 0).map { Store.p.getInt("day_" + java.time.LocalDate.now().minusDays(it.toLong()), 0) }
    }
    fun complete(m: Mission) {
        if (m.id in done) return
        done = done + m.id
        xp += m.xp
        stats = stats + (m.attr to (stats[m.attr] ?: 0) + 1)
        if (m.id == "pf") streak += 1
        power = (power - 10).coerceAtLeast(0)
        if (power == 0 && bossIdx < bosses.lastIndex) { bossIdx += 1; power = 100; defeated += 1 }
        save()
    }
    // Setback is only ever recorded by the user. XP and stats are never erased.
    fun setback() { power = (power + 10).coerceAtMost(100); streak = 0; save() }
    fun reset() { Store.p.edit().clear().apply(); load() }
}
